# Horizons Week 1 Day 1 Exercises

## Pair Programming Exercises

1. [Week 1 Setup](git.md)
1. [Debugging with Chrome DevTools](debug.md)
1. Rocketship object: <br>
   Files: `week01/day1/rocketship.js` and `week01/day1/rocketship.html`
1. [JavaScript Built-ins](js_builtins.md)
1. [Function Arguments](var_args.md)
1. [Calculator](util_calc.md)
1. [**Bonus:** Poker Hands](poker.md)
