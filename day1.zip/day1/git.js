"use strict";

describe("Inline exercise", function() {
  it("Fix this test", function() {
    expect(true).toBe(true);
  });
});
