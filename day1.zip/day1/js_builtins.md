# Pair Programming Exercise: JavaScript Built-ins

## Goal

The goal of this exercise is to build familiarity with built-in Array and String function in JavaScript. We will be using and replicating useful built-in functions.

## Instructions

1. Open `week01/day1/js_builtins.js` in your text editor. Exercise details are listed there.
1. Open `week01/day1/js_builtins.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.
