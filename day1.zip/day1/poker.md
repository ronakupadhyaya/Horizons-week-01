# Bonus Pair Programming Exercise: Poker Hands

## Goal

The goal of this exercise is to build a function that takes two poker hands and
determines which one is the winner. It requires you to handle many fallback
conditions for tie breakers.

## Instructions

1. Open `week01/day1/poker.js` in your text editor. Exercise details are listed there.
1. Open `week01/day1/poker.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.

