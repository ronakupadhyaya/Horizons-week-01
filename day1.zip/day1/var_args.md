# Pair Programming Exercise: Function Arguments

## Goal

The goal of this exercise is to familiarize yourself with the JavaScript function `arguments` object.

## Instructions

1. Open `week01/day1/var_args.js` in your text editor. Exercise details are listed there.
1. Open `week01/day1/var_args.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.
