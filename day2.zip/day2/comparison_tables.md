# Pair Programming Exercise: Truth Comparison Tables

## Goal

The goal of this exercise is to compare the behavior of JavaScript operators
`==` and `===`.

## Instructions

1. Open `week01/day2/comparison_tables.js` in your text editor. Exercise details are listed there.
1. Open `week01/day2/comparison_tables.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.
