# Pair Programming Exercise: Student Grades

## Goal

The goal of this exercise is to learn how to use
[Underscore.js](http://underscorejs.org/) to extract useful information
from data sets.

## Instructions

1. Open `week01/day2/grades.js` in your text editor. Exercise details are listed there.
1. Open `week01/day2/grades.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.
