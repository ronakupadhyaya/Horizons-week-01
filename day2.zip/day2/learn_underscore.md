# Pair Programming Exercise: Learning Underscore.js

## Goal

[Underscore.js](http://underscorejs.org/) is a library that provides
a ton of useful functionality that is not available in JavaScript
out of the box. This exercise will teach you how to use Underscore.

## Instructions

1. Open `week01/day2/learn_underscore.js` in your text editor. Exercise details are listed there.
1. Open `week01/day2/learn_underscore.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.
