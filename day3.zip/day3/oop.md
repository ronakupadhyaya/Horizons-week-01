# Inline Exercise: Object Oriented Programming

## Time limit: 10 minutes

## Instructions

1. Open `week01/day3/oop.js` in your text editor. Exercise details are listed there.
1. Open `week01/day3/oop.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.

