// This function will set window.lion to a
// string called 'lion'. When changing the code
// you are not allowed to alter the existing code
// in any way.

(function() {
  function getAnimal() {
    return 'lion';
  }

  window.lion = getAnimal();
}())

// This function will set window.tiger to a
// string called 'tiger'. When changing the code
// you are not allowed to alter the existing code
// in any way.

(function() {
  function getAnimal() {
    return 'tiger';
  }

  window.tiger = getAnimal();
}())
