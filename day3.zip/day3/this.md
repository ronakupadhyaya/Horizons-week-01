# Warmup Exercise: The `this` keyword

## Time limit: 15 minutes

## Instructions

1. Open `week01/day3/this.js` in your text editor. Exercise details are listed there.
1. Open `week01/day3/this.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.

