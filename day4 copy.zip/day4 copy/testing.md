# Inline Exercise: Testing

## Time limit: 10 minutes

## Instructions

1. Open `week01/day4/testing.js` in your text editor. Exercise details are listed there.
1. Open `week01/day4/testing.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.


