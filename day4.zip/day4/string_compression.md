# Warmup Exercise: String Compression

## Time limit: 15 minutes

## Instructions

1. Open `week01/day4/string_compression.js` in your text editor. Exercise details are listed there.
1. Open `week01/day4/string_compression.html` in your browser to run tests.
1. Write necessary functions to make all the tests pass.


